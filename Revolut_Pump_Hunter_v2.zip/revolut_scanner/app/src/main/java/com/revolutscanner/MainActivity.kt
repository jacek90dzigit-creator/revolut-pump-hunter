package com.revolutscanner

import android.Manifest
import android.app.*
import android.content.*
import android.graphics.*
import android.os.*
import android.view.*
import android.widget.*
import androidx.core.app.ActivityCompat
import org.json.JSONArray
import kotlin.math.max

class MainActivity: Activity(){
    private lateinit var content:LinearLayout
    private lateinit var status:TextView
    private lateinit var threshold:EditText
    private lateinit var minutes:EditText
    private val prefs by lazy{getSharedPreferences("pump_hunter",MODE_PRIVATE)}
    override fun onCreate(b:Bundle?){super.onCreate(b);if(Build.VERSION.SDK_INT>=33)ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.POST_NOTIFICATIONS),10);build()}
    private fun build(){
        val root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,22,20,16);setBackgroundColor(Color.rgb(11,13,16))}
        val title=TextView(this).apply{text="REVOLUT PUMP HUNTER";textSize=24f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
        val sub=TextView(this).apply{text="Public market scanner • bez logowania";textSize=13f;setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;padding(0,6,0,14)}
        val tabs=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        fun tab(label:String,action:()->Unit)=Button(this).apply{text=label;setOnClickListener{action()};tabs.addView(this,LinearLayout.LayoutParams(0,52,1f))}
        tab("🔥 PUMP"){showPump()};tab("📈 AKTYWNE"){showActive()};tab("🚪 EXIT"){showExit()};tab("⚙ USTAWIENIA"){showSettings()}
        content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(0,12,0,0)}
        root.addView(title);root.addView(sub);root.addView(tabs);root.addView(content,LinearLayout.LayoutParams(-1,0,1f));setContentView(root);showActive()
    }
    private fun showPump(){content.removeAllViews(); val h=header("🔥 Pump Hunter","Wykrywa świeże dynamiczne ruchy na publicznych danych Revolut X.");content.addView(h);content.addView(note("Próg domyślny: +5% w 30 min. Alert wymaga pełnego okna danych, więc po pierwszym uruchomieniu skaner potrzebuje czasu na zbudowanie historii."));val list=loadPumps().filter{it.status=="ACTIVE"};if(list.isEmpty())content.addView(note("Brak aktywnych pumpów. Skaner pracuje w tle.")) else list.sortedByDescending{it.pumpScore}.forEach{addPumpCard(it)}}
    private fun showActive(){content.removeAllViews();content.addView(header("📈 Aktywne pumpy","Każdy wykryty pump jest śledzony aż do zakończenia ruchu."));val list=loadPumps().filter{it.status=="ACTIVE"||it.status=="EXIT_WATCH"};if(list.isEmpty())content.addView(note("Na razie nic nie jest aktywnie śledzone."));list.sortedByDescending{it.changePct}.forEach{addPumpCard(it)}}
    private fun showExit(){content.removeAllViews();content.addView(header("🚪 Exit Signal","Pokazuje tylko wcześniej wykryte pumpy, w których pojawiają się oznaki słabnięcia ruchu."));val list=loadPumps().filter{it.status=="EXIT_SIGNAL"||it.status=="EXIT_WATCH"};if(list.isEmpty())content.addView(note("Brak sygnałów exitu."));list.sortedByDescending{it.exitScore}.forEach{addPumpCard(it,true)}}
    private fun showSettings(){content.removeAllViews();content.addView(header("⚙ Ustawienia","Skaner korzysta wyłącznie z publicznych danych. Nie podajesz loginu ani klucza Revolut."));threshold=field("Próg PUMP (%)","5");minutes=field("Okno PUMP (min)","30");content.addView(threshold);content.addView(minutes);val start=Button(this).apply{text="START PUMP HUNTER";setOnClickListener{startScanner()}};val stop=Button(this).apply{text="STOP";setOnClickListener{stopService(Intent(this@MainActivity,ScannerService::class.java));status.text="🔴 zatrzymany"}};content.addView(start);content.addView(stop);status=TextView(this).apply{text="Status: gotowy";setTextColor(Color.LTGRAY);textSize=15f};content.addView(status);content.addView(note("Uwaga: Exit Signal jest sygnałem analitycznym, nie gwarancją dobrego momentu sprzedaży."))}
    private fun startScanner(){val i=Intent(this,ScannerService::class.java).putExtra("threshold",threshold.text.toString().toDoubleOrNull()?:5.0).putExtra("minutes",minutes.text.toString().toIntOrNull()?:30);if(Build.VERSION.SDK_INT>=26)startForegroundService(i)else startService(i);status.text="🟢 działa • skan co 60 s"}
    private fun addPumpCard(p:PumpState,exit:Boolean=false){val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(16,14,16,14);setBackgroundColor(Color.rgb(24,27,33));};val title=TextView(this).apply{text="${p.symbol}  ${if(p.status=="EXIT_SIGNAL")"🚪" else if(p.status=="EXIT_WATCH")"🟠" else "🚀"}";textSize=20f;setTextColor(Color.WHITE)};val body=TextView(this).apply{text="Zmiana: %.2f%%\nSzczyt: %.6f\nOd szczytu: %.2f%%\nPump Score: %d/8\nExit Score: %d/100".format(p.changePct,p.peak,p.drawdownPct,p.pumpScore,p.exitScore);textSize=15f;setTextColor(Color.LTGRAY);setPadding(0,8,0,8)};box.addView(title);box.addView(body);val chart=MiniChart(this,p);box.addView(chart,LinearLayout.LayoutParams(-1,170));if(exit)box.addView(note("Sygnał oznacza rosnące ryzyko zakończenia pumpa. Nie jest automatycznym poleceniem sprzedaży."));content.addView(box,LinearLayout.LayoutParams(-1,260).apply{setMargins(0,0,0,10)})}
    private fun header(a:String,b:String)=TextView(this).apply{text="$a\n$b";textSize=18f;setTextColor(Color.WHITE);setPadding(4,8,4,14)}
    private fun note(t:String)=TextView(this).apply{text=t;textSize=14f;setTextColor(Color.LTGRAY);setPadding(8,8,8,12)}
    private fun field(h:String,v:String)=EditText(this).apply{hint=h;setText(v);setTextColor(Color.WHITE);setHintTextColor(Color.GRAY);inputType=2;setPadding(8,8,8,8)}
    private fun loadPumps():List<PumpState>{return try{val a=JSONArray(prefs.getString("pumps","[]"));buildList{for(i in 0 until a.length())add(PumpState.fromJson(a.getJSONObject(i)))}}catch(_:Throwable){emptyList()}}
    private fun LinearLayout.padding(l:Int,t:Int,r:Int,b:Int){setPadding(l,t,r,b)}
}

class MiniChart(ctx:android.content.Context,private val p:PumpState):View(ctx){private val paint=Paint(Paint.ANTI_ALIAS_FLAG);override fun onDraw(c:Canvas){super.onDraw(c);paint.style=Paint.Style.STROKE;paint.strokeWidth=5f;paint.color=Color.rgb(80,210,150);val w=width.toFloat();val h=height.toFloat();val start=p.entry;val top=max(p.peak,start*1.001);val end=p.last;val pts=floatArrayOf(0f,h*.78f,w*.22f,h*.65f,w*.45f,h*.35f,w*.65f,h*.18f,w,h*.55f);if(end<top)pts[pts.size-1]=h*.45f;c.drawPath(Path().apply{moveTo(pts[0],pts[1]);for(i in 2 until pts.size step 2)lineTo(pts[i],pts[i+1])},paint);paint.style=Paint.Style.FILL;paint.color=Color.GRAY;c.drawText("entry",4f,h-8,paint);c.drawText("peak",w*.65f,h-8,paint)}}
