package com.revolutscanner

import android.app.*
import android.content.*
import android.os.*
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import java.util.concurrent.ConcurrentHashMap
import kotlin.concurrent.thread

class ScannerService: Service() {
    private val history=ConcurrentHashMap<String,ArrayDeque<Pair<Long,Double>>>()
    private val lastAlert=ConcurrentHashMap<String,Long>()
    private val pumps=ConcurrentHashMap<String,PumpState>()
    private var running=true; private var threshold=5.0; private var windowMinutes=30; private var cooldownMs=60*60_000L
    private val prefs by lazy { getSharedPreferences("pump_hunter",MODE_PRIVATE) }
    override fun onStartCommand(i:Intent?,flags:Int,startId:Int):Int {
        threshold=i?.getDoubleExtra("threshold",5.0)?:5.0; windowMinutes=i?.getIntExtra("minutes",30)?:30
        startForeground(7,notification("Scanner aktywny • +${threshold}% / ${windowMinutes}m")); loadPumps()
        thread(name="scanner"){loop()}; return START_STICKY
    }
    private fun loop(){while(running){try{scan()}catch(_:Throwable){};Thread.sleep(60_000)}}
    private fun scan(){
        val now=System.currentTimeMillis(); val ticks=RevolutApi.tickers()
        for(t in ticks){
            val q=history.getOrPut(t.symbol){ArrayDeque()}; q.addLast(now to t.price); while(q.isNotEmpty()&&now-q.first().first>2*60*60_000L)q.removeFirst()
            val old=q.firstOrNull{now-it.first>=windowMinutes*60_000L}?:continue
            val ch=(t.price/old.second-1)*100
            val prev=q.dropLast(1).takeLast(6).map{it.second}; val momentum=if(prev.size>=2)(t.price/prev.first()-1) else 0.0
            val volBoost=if(t.volume24h>0)1.0 else 0.0
            if(ch>=threshold && !pumps.containsKey(t.symbol) && now-(lastAlert[t.symbol]?:0)>cooldownMs){
                val score=SignalEngine.pumpScore(ch,momentum,volBoost,1.0); pumps[t.symbol]=PumpState(t.symbol,now,old.second,t.price,t.price,now,score,0,ch,0.0,momentum); persist(); lastAlert[t.symbol]=now; notifyPump(t,ch,score)
            }
            pumps[t.symbol]?.let{p->
                p.last=t.price; p.changePct=(t.price/p.entry-1)*100
                if(t.price>p.peak){p.peak=t.price;p.peakAt=now}
                p.drawdownPct=(t.price/p.peak-1)*100
                p.momentum=momentum; p.exitScore=SignalEngine.exitScore(p.drawdownPct,momentum,volBoost,1.0)
                if(p.exitScore>=70 && p.status=="ACTIVE"){p.status="EXIT_SIGNAL"; notifyExit(t,p)}
                else if(p.exitScore>=45 && p.status=="ACTIVE"){p.status="EXIT_WATCH"}
            }
            persist()
        }
    }
    private fun notifyPump(t:Tick,ch:Double,score:Int){val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager; nm.notify((t.symbol.hashCode()and 0x7fffffff),NotificationCompat.Builder(this,"pump").setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle("🚀 PUMP • ${t.symbol}").setContentText("+%.2f%% / %dm • Pump %d/8".format(ch,windowMinutes,score)).setPriority(NotificationCompat.PRIORITY_HIGH).build())}
    private fun notifyExit(t:Tick,p:PumpState){val nm=getSystemService(NOTIFICATION_SERVICE) as NotificationManager; nm.notify((t.symbol.hashCode()and 0x7fffffff)+100000,NotificationCompat.Builder(this,"pump").setSmallIcon(android.R.drawable.stat_sys_warning).setContentTitle("🚪 EXIT SIGNAL • ${t.symbol}").setContentText("Exit score ${p.exitScore}/100 • %.2f%% od wejścia • %.2f%% od szczytu".format(p.changePct,p.drawdownPct)).setStyle(NotificationCompat.BigTextStyle().bigText("To sygnał ryzyka zakończenia wcześniej wykrytego pumpa, nie gwarancja sprzedaży.\nMomentum: %.3f".format(p.momentum))).setPriority(NotificationCompat.PRIORITY_HIGH).build())}
    private fun notification(text:String):Notification{val nm=getSystemService(NOTIFICATION_SERVICE)as NotificationManager;if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel("pump","Pump Hunter",NotificationManager.IMPORTANCE_HIGH));return NotificationCompat.Builder(this,"pump").setSmallIcon(android.R.drawable.stat_notify_sync).setContentTitle("Revolut Pump Hunter").setContentText(text).setOngoing(true).build()}
    private fun persist(){val a=JSONArray();pumps.values.forEach{a.put(it.toJson())};prefs.edit().putString("pumps",a.toString()).apply()}
    private fun loadPumps(){try{val a=JSONArray(prefs.getString("pumps","[]"));for(i in 0 until a.length()){val p=PumpState.fromJson(a.getJSONObject(i));if(p.status!="CLOSED")pumps[p.symbol]=p}}catch(_:Throwable){}}
    override fun onDestroy(){running=false;super.onDestroy()};override fun onBind(i:Intent?)=null
}
