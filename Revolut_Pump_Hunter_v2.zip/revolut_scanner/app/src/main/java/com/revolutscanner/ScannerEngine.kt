package com.revolutscanner

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min

/** Public market-data client. No Revolut login or API key is used. */
data class Tick(val symbol: String, val price: Double, val volume24h: Double, val change24h: Double)
data class Candle(val start: Long, val open: Double, val high: Double, val low: Double, val close: Double, val volume: Double)
data class PumpState(
    val symbol: String, val startedAt: Long, var entry: Double, var last: Double,
    var peak: Double, var peakAt: Long, var pumpScore: Int, var exitScore: Int,
    var changePct: Double, var drawdownPct: Double, var momentum: Double,
    var status: String = "ACTIVE"
) {
    fun toJson() = JSONObject().apply {
        put("symbol", symbol); put("startedAt", startedAt); put("entry", entry); put("last", last)
        put("peak", peak); put("peakAt", peakAt); put("pumpScore", pumpScore); put("exitScore", exitScore)
        put("changePct", changePct); put("drawdownPct", drawdownPct); put("momentum", momentum); put("status", status)
    }
    companion object { fun fromJson(o: JSONObject) = PumpState(o.getString("symbol"),o.getLong("startedAt"),o.getDouble("entry"),o.getDouble("last"),o.getDouble("peak"),o.getLong("peakAt"),o.getInt("pumpScore"),o.getInt("exitScore"),o.getDouble("changePct"),o.getDouble("drawdownPct"),o.getDouble("momentum"),o.optString("status","ACTIVE")) }
}

object RevolutApi {
    private const val BASE = "https://revx.revolut.com/api/1.0/public/"
    private fun get(path: String): JSONObject {
        val c = URL(BASE + path).openConnection() as HttpURLConnection
        c.connectTimeout = 10000; c.readTimeout = 10000; c.requestMethod = "GET"
        if (c.responseCode !in 200..299) throw IllegalStateException("HTTP ${c.responseCode}")
        return c.inputStream.bufferedReader().use { JSONObject(it.readText()) }
    }
    fun tickers(): List<Tick> {
        val arr = get("tickers?region=EEA").getJSONArray("data")
        return buildList { for (i in 0 until arr.length()) { val o=arr.getJSONObject(i); val p=o.optDouble("last_price",o.optDouble("mid_price",0.0)); if(p>0) add(Tick(o.optString("symbol"),p,o.optDouble("volume_24h",0.0),o.optDouble("price_change_24h",0.0))) } }
    }
    fun candles(symbol: String, minutes: Int): List<Candle> {
        val now=System.currentTimeMillis(); val since=now-minutes*60_000L
        val encoded=symbol.replace("/","-")
        val arr=get("candles/$encoded?interval=5&since=$since&until=$now&region=EEA").getJSONArray("data")
        return buildList { for(i in 0 until arr.length()){val o=arr.getJSONObject(i); add(Candle(o.getLong("start"),o.getString("open").toDouble(),o.getString("high").toDouble(),o.getString("low").toDouble(),o.getString("close").toDouble(),o.optString("volume","0").toDouble()))} }
    }
}

object SignalEngine {
    fun pumpScore(change: Double, momentum: Double, volumeBoost: Double, volatility: Double): Int {
        var s=0; if(change>=5) s+=3 else if(change>=3) s+=2 else if(change>=2) s++
        if(momentum>=0.15) s+=2 else if(momentum>=0.05) s++
        if(volumeBoost>=2) s+=2 else if(volumeBoost>=1.3) s++
        if(volatility>=1.2) s++
        return s.coerceIn(0,8)
    }
    fun exitScore(drawdown: Double, momentum: Double, volumeRatio: Double, volatility: Double): Int {
        var s=0
        if(drawdown<=-6) s+=40 else if(drawdown<=-4) s+=30 else if(drawdown<=-2.5) s+=18 else if(drawdown<=-1.5) s+=8
        if(momentum<0) s+=25 else if(momentum<0.05) s+=10
        if(volumeRatio>=1.8) s+=20 else if(volumeRatio>=1.3) s+=10
        if(volatility>=1.5) s+=15 else if(volatility>=1.2) s+=8
        return s.coerceIn(0,100)
    }
}
